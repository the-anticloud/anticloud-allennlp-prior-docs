# 19 System Of Things Sot

**Project:** ALLENNLP
**Upstream:** https://github.com/allenai/allennlp

Content specific to ALLENNLP in category ACADEMIA_RD.
