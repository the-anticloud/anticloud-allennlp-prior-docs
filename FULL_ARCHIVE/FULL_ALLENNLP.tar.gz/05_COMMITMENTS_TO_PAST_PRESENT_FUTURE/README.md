# 05 Commitments To Past Present Future

**Project:** ALLENNLP
**Upstream:** https://github.com/allenai/allennlp

Content specific to ALLENNLP in category ACADEMIA_RD.
