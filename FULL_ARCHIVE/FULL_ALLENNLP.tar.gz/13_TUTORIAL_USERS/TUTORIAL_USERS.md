# Tutorial — Users — ALLENNLP

**Company:** Anticloud FZ LLE
**Model:** PAX L5 Narrow L2 General 27B
**Project:** ALLENNLP | Category: ACADEMIA_RD
**Upstream:** https://github.com/allenai/allennlp (Apache 2.0)

## Overview

This document covers tutorial — users for the Anticloud integration of ALLENNLP.

NLP research library for academic experiments

## Anticloud Integration

PAX L5 Narrow L2 General 27B is integrated into ALLENNLP to provide:
- Local AI inference with zero cloud dependency
- AIOSS tamper-evident audit chain
- AES-256 encryption at rest
- Single-binary deployment

## Contact

Lois-Kleinner Alpasan — CEO & CTO, Anticloud FZ LLE
lois@0-1.gg | 0-1.gg
