# 23 How To Cite

**Project:** ALLENNLP
**Upstream:** https://github.com/allenai/allennlp

Content specific to ALLENNLP in category ACADEMIA_RD.
